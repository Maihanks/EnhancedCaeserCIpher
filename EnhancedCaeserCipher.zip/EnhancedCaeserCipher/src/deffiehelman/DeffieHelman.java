/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package deffiehelman;

import com.maihanks.Utitlities.DateAndTime;
import com.maihanks.Utitlities.Utilities;

/**
 *
 * @author MAIHANKS
 */
public class DeffieHelman {

    static final DateAndTime dt = new DateAndTime();
    public static final int date = Integer.parseInt(dt.getCurrentDayDate());
    public static int p = 13;// Utilities.generateNextPrime(date) * 20;
    public static int g = 5;
    public static int secretNumberA = 0, cryptoKey = 0, commonKey;

    /**
     * @param args the command line arguments
     */
    public static int generateCryptoKey(int secretNumberA2) {
        secretNumberA = secretNumberA2;
        int power = (int) (Math.pow(g, secretNumberA));
//        System.out.println(g + "^" + secretNumberA + " = " + power);
        cryptoKey = power % p;
//        System.out.println(g + "^" + secretNumberA + " mod " + p + " = " + cryptoKey);
        return cryptoKey;
    }

    public static int generateP(int numA, int numB) {
        int prime = 0;
        int average = numA / numB;
        prime = Utilities.generateNextPrime(average);
        return prime;
    }

    public static void setP(int value) {
        p = value;
    }

    public static int generateCommonKey(int secretNumberA2, int cryptoKey2) {
        secretNumberA = secretNumberA2;
        cryptoKey = cryptoKey2;

        int power = (int) (Math.pow(cryptoKey, secretNumberA));
  //      System.out.println(cryptoKey + "^" + secretNumberA + " = " + power);
        commonKey = power % p;
  //      System.out.println(cryptoKey + "^" + secretNumberA + " mod " + p + "=" + cryptoKey);
  //      System.out.println("common key = " + commonKey);
        return commonKey;
    }

    public static int getCommonKey() {
        return commonKey;
    }

    /*
     * 
     (ga mod p)b mod p = gab mod p
     (gb mod p)a mod p = gba mod p
     */
    public static void main(String[] args) {
        int secretNo1 = 4;
        int secretNo2 = 15;
        //       System.out.println(Utilities.isNumberPrime(secretNo2));

        int c1 = generateCryptoKey(secretNo1);
        int c2 = generateCryptoKey(secretNo2);

        int key1 = generateCommonKey(secretNo1, c2);
        int key2 = generateCommonKey(secretNo2, c1);

        // TODO code application logic here
        System.out.println("key 1 = " + key1);
        System.out.println("key 2 = " + key2);
    }
}
