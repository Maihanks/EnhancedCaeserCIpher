/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.kuw.server;

import com.maihanks.kuw.general.Message;
import java.io.Serializable;

/**
 *
 * @author MAIHANKS
 */
public class ServerMessage implements Serializable, Message {

    private String sender = "server", receiver, messageSendingDate, messageReceivingDate;
    private String[] message;
    boolean clientLoginStatus = false;    

    public byte[] imageBytes;
    private int theMessageType;
//the type of messages which the clint can send to the server  
    public static final int DEFAULT = -100, MESSAGE_TYPE_CONNECTION_TERMINATED = 0, MESSAGE_TYPE_SUCCESSFUL_EXECUTION_OF_MESSAGE_TYPE_SEND_MY_KEY_REQUEST=-58,
            SENDING_KEY_REQUEST =-59, KEY_SENT_SUCCESSFULLY =-60,SEND_MESSAGE_TO_OTHER_CLIENTS_REQUEST = -61;

    public ServerMessage(String theSender, String receiver, int theMessageType, String[] theMessage) {
        this.sender = theSender;
        this.theMessageType = theMessageType;
        message = theMessage;
    }
//      public File getFileMessage() {
//        return fileMessage;
//    }
//
//    public void setFileMessage(File fileMessage) {
//        this.fileMessage = fileMessage;
//    }
public byte[] getImageBytes(){
return imageBytes;
}
    public String getMessageReceivingDate() {
        return messageReceivingDate;
    }

    public void setMessageReceivingDate(String messageReceivingDate) {
        this.messageReceivingDate = messageReceivingDate;
    }


    public int getTheMessageType() {
        return theMessageType;
    }

    public void setTheMessageType(int theMessageType) {
        this.theMessageType = theMessageType;
    }

    
    /*
     /*
     *-login request status boolean(0/false-invalid user, 1/true-valid user)
     * -successful creation of client:staff,student
     * -input scores {coursecode }
     * -view scores {coursecode,score}
     * -update profile{username,password,names,sex,role,}
     */
    /**
     * defines the message type to enable appropriate response from the server
     */
//public static enum MessageType { a normal message*/NORMAL_MESSAGE,/**a request message that prompts validating user */LOGIN_REQUEST,
    /**
     * a request message that prompts the server to register user REGISTER_USER};
     */    

    private void analyzeIncomingMessage() {
    }//end analyzeIncomingMessage()

    @Override
    public String getSender() {
        return this.sender;
    }

    @Override
    public String getReceiver() {
        return this.receiver;
    }

    @Override
    public String getMessageSendingDate() {
        return this.messageSendingDate;
    }

    @Override
    public String getMessageReceiveingDate() {
        return this.messageReceivingDate;
    }

    @Override
    public String[] getMessage() {
        return this.message;
    }

    @Override
    public String getMessageSendingTime() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    /**
     * returns this message's type as depicted by enum messageType
     *
     * @return
     */
    public int getMessageType() {
        return theMessageType;
    }

    public void setMessageType(int messageType) {
        theMessageType = messageType;
    }

    public void setClientLoginStatus(boolean theLoginStatus) {
        clientLoginStatus = theLoginStatus;
    }

    public boolean getClientLoginStatus() {
        return clientLoginStatus;
    }

    @Override
    public void setSender(String theSender) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
