/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.kuw.server;

import com.maihanks.kuw.server.TheServer;

public class LaunchServer {

    public static void main(String[] args) {
        TheServer server = new TheServer();
        server.runServer();
    }
}
