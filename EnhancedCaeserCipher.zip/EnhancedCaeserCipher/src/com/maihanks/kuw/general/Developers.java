/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.kuw.general;

/**
 *
 * @author MAIHANKS
 */
public class Developers {
    public static String[] developer = { "Munura Maihankali"};
    
    public static final String  Munura="Munura Maihankali";
}
