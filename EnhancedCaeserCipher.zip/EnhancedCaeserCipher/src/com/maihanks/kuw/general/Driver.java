/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.kuw.general;

import com.maihanks.kuw.client.Client;
import com.maihanks.kuw.server.TheServer;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author MAIHANKS
 */
public class Driver extends JFrame {

    private JButton serverButton = new JButton("LAUNCH SERVER");
    private JButton clientButton = new JButton("LAUNCH CLIENT");
    private String username, password;
    private boolean loginSucess = false;
    private JPanel parentPanel = new JPanel();
    private JPanel inputPanel = new JPanel();

    public Driver() {
        super("Diffi-Helman Technique");
        super.setBounds(500, 200, 350, 150);
//       super.setLayout(new GridLayout(5,3));
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        super.setResizable(false);
        super.setLayout(null);
        setUpDislay();
    }

    private void setUpDislay() {
        setUpParentPanelComponents();
    }

    private void setUpParentPanelComponents() {
        parentPanel.setLayout(null);
        parentPanel.setBounds(0, 0, super.getWidth(), super.getHeight());
        inputPanel.setBounds(0, 0, parentPanel.getWidth(), parentPanel.getHeight());
        inputPanel.setLayout(null);
        //descLabels[0],usernameTextField,descLabels[1],passwordTextField,descLabels[2],serverButton
        serverButton.setBounds(5, 20, 150, 80);
        clientButton.setBounds(170, 20, 150, 80);

        inputPanel.add(clientButton);
        inputPanel.add(serverButton);
        parentPanel.add(inputPanel);

        super.add(parentPanel);
    }

    public void start() {
        registerEventHandler();
        // Login login = this;
        super.setVisible(true);
    }

    /**
     * registers events
     */
    private void registerEventHandler() {
        serverButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TheServer server = new TheServer();
                server.runServer();
                dispose();
            }
        });

        clientButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                                dispose();
                String defaultHostIpAddress = "127.0.0.1";
                String serverIpAddress = null;
                serverIpAddress = JOptionPane.showInputDialog(null, "Enter Server IP Address", defaultHostIpAddress);
                if (!serverIpAddress.equals(null)) {
                    Client application;
                    application = new Client(serverIpAddress);
                    application.runClient();
                } else {
                    serverIpAddress = JOptionPane.showInputDialog(null, "Enter Server IP Address", defaultHostIpAddress);
                }

            }
        });
    }

    public static void main(String[] args) {
       // new Driver().start();
        
        
        String choice = JOptionPane.showInputDialog(null, "Enter choice\n1 Server\n 2 Client");
        
        if(choice.equals("1")){
                        TheServer server = new TheServer();
                server.runServer();
                
        }else if(choice.equals("2")){
                        String defaultHostIpAddress = "127.0.0.1";
                String serverIpAddress = null;
                serverIpAddress = JOptionPane.showInputDialog(null, "Enter Server IP Address", defaultHostIpAddress);
                if (!serverIpAddress.equals(null)) {
                    Client application;
                    application = new Client(serverIpAddress);
                    application.runClient();
                } else {
                    serverIpAddress = JOptionPane.showInputDialog(null, "Enter Server IP Address", defaultHostIpAddress);
                }
        }else{
        JOptionPane.showMessageDialog(null, "Program terminated, invalid choice");
        }
    }
}
