/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.kuw.client;

import javax.swing.JOptionPane;

/**
 *
 * @author ANDYAR
 */
public class LaunchClient {

    public static void main(String[] args) {
        String defaultHostIpAddress = "127.0.0.1";
        String serverIpAddress = null;
        serverIpAddress = JOptionPane.showInputDialog(null, "Enter Server IP Address", defaultHostIpAddress);
        if (!serverIpAddress.equals(null)) {
            Client application;
            application = new Client(serverIpAddress);
            application.runClient();
        } else {
            serverIpAddress = JOptionPane.showInputDialog(null, "Enter Server IP Address", defaultHostIpAddress);
        }

    }
}
