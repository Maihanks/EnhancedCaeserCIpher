/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.kuw.client;

import com.maihanks.Utitlities.*;
import com.maihanks.kuw.server.ServerMessage;
import deffiehelman.CaesarCipher;
import deffiehelman.DeffieHelman;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import javax.swing.*;

/**
 *
 * @author BUDI
 */
public class Client {

    public JFrame parentFrame = new JFrame("Client");
    private JTextField enterField;
    private JTextArea displayArea;
    private ObjectOutputStream output = null;
    private ObjectInputStream input = null;
    private String message;
    private String serverIpAddress;
    private Socket client;
    private int port = 12345;
    private int key = -1;
    private Client clientObj;
    private ClientMessage clientMessage;
    public ServerMessage serverMessage = null;
    public String clientUsername;
    private JTextField clientNoTextField;
    private JPanel parentPanel = new JPanel();
    private JPanel infoPanel = new JPanel();
    private JLabel keyLabel = new JLabel("Key");
    private JTextField keyTextField = new JTextField();
    public JTextField receivedKeyTextField = new JTextField();
    public JTextField commonKeyTextField = new JTextField();
    public JTextField secretNumberATextField = new JTextField();
    private JButton generateCommonKeyButton = new JButton("Create Key");
    private JButton resetButton = new JButton("Reset");
    private DateAndTime dateAndTime = new DateAndTime();
    private ServerMessage serverIncomingMessage;
    private String theCurrentClientUsername, theCurrentClientPassword, theCurrentClientCategory;
    private boolean theCurrentClientloginStatus = false;
//    public DeleteStudentProfileHome deleteStudentProfileHomeObj;

    JLabel headerLabel = new JLabel();
    JLabel serverIpAddressLabel = new JLabel("SERVER IP ADDRESS");
    JTextField serverIpAddressTextField = new JTextField();
    JTextField myGeneratorTextField = new JTextField();
//    JLabel myPrimeLabel = new JLabel("Prime No.");
    JButton connectToServerButton = new JButton("Connect to Server");
    JLabel messageTextAreaLabel = new JLabel("Message"), receivedMessageLabel = new JLabel("Received Message"),
            decryptedMessageLabel = new JLabel("Decrypted Message");
    JTextArea messageTextArea = new JTextArea(), receivedMessageTextArea = new JTextArea(), decryptedMessageTextArea = new JTextArea();
    JButton sendMyKeyButton = new JButton("Send Key"), statisticsButton = new JButton("Statistics"), sendMessageButton = new JButton("Send Message"),
            decryptMessageButton = new JButton("Decrypt Message");
    boolean connectionStatus = false;
    String theStudentClearanceStatus = "0";
    int sNumberA, publicNo, theOSecretNo, theAv;
    String r = "";
    String displayedReceived = "";
    int[] receivedKeys = new int[com.maihanks.kuw.server.TheServer.MAX_NUM_OF_CLIENTS];
    int receivedKeysCounter = 0;

    public void setServerIpAddress(String theServerIpAddress) {
        serverIpAddress = theServerIpAddress;
    }

    public String getServerIpAddress() {
        return serverIpAddress;
    }

  

    public Client(String host) {
        serverIpAddress = host;
        setupParentFrameComponents();
    }

    private void setupParentFrameComponents() {
        parentPanel.setLayout(null);
        parentFrame.setBounds(100, 50, 1100, 600);
        parentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        parentFrame.setResizable(false);

        setupParentPanelComponents();

        parentFrame.setVisible(true);
    }

    private void setupParentPanelComponents() {
        //set up parent components
        parentPanel.setLayout(null);//
        parentPanel.setBounds(0, 0, parentFrame.getWidth(), parentFrame.getHeight());
        parentPanel.setBackground(Color.DARK_GRAY);
        displayArea = new JTextArea();
        displayArea.setBounds(5, 0, parentPanel.getWidth(), 50);
        serverIpAddressLabel.setBounds(0, 0, 150, 30);
        serverIpAddressTextField.setBounds(150, 0, 150, 30);
        connectToServerButton.setBounds(320, 0, 150, 30);
        serverIpAddressLabel.setForeground(Color.WHITE);

        infoPanel.setBounds(30, displayArea.getHeight() + 90, parentPanel.getWidth() - 50, parentPanel.getHeight() - displayArea.getHeight() - 150);
        infoPanel.setBackground(Color.lightGray);
        infoPanel.setLayout(null);
        JLabel secretNumberALabel = new JLabel("Secret No"), receivedKeyLabel = new JLabel("Received Key"), commonKeyLabel = new JLabel("Common Key");

        secretNumberALabel.setBounds(5, 10, 100, 30);
        secretNumberATextField.setBounds(110, 10, 100, 30);
        //************************************************************
        myGeneratorTextField.setBounds(220, 10, 50, 30);

        sendMyKeyButton.setBounds(280, 10, 120, 30);

        resetButton.setBounds(410, 10, 90, 30);
        receivedKeyLabel.setBounds(540, 10, 100, 30);
        receivedKeyTextField.setBounds(650, 10, 120, 30);

        generateCommonKeyButton.setBounds(780, 10, 150, 30);
        commonKeyTextField.setBounds(950, 10, 70, 30);

        messageTextAreaLabel.setBounds(105, 50, 100, 30);
        receivedMessageLabel.setBounds(405, 50, 200, 30);
        decryptedMessageLabel.setBounds(650, 50, 200, 30);

        messageTextArea.setBounds(5, 82, 300, 315);
        receivedMessageTextArea.setBounds(310, 82, 300, 315);
        decryptedMessageTextArea.setBounds(615, 82, 400, 315);


        sendMessageButton.setBounds(200, 540, 130, 30);
        decryptMessageButton.setBounds(650, 540, 200, 30);
        statisticsButton.setBounds(900, 540, 100, 30);
        keyLabel.setBounds(390, 540, 50, 30);
        keyTextField.setBounds(450, 540, 100, 30);
        keyLabel.setForeground(Color.WHITE);
        headerLabel.setBackground(Color.DARK_GRAY);

        commonKeyTextField.setEditable(false);
        receivedMessageTextArea.setEditable(false);
        //receivedKeyTextField.setEditable(false);


        /**
         * serverIpAddressLabel.setBounds(0,0,150,30);
         * serverIpAddressTextField.setBounds(150,0,150,30);
         * connectToServerButton.setBounds(320,0,150,30);
         */
        headerLabel.setBounds(50, displayArea.getHeight(), parentPanel.getWidth() - 50, 70);
        headerLabel.setForeground(Color.RED);
        headerLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD + Font.ITALIC, 25));
        headerLabel.setText("Diffie-Hellman Technique ");
        parentPanel.add(headerLabel);


        infoPanel.add(secretNumberALabel);
        infoPanel.add(secretNumberATextField);

//        infoPanel.add(myGeneratorLabel);
//        infoPanel.add(myGeneratorTextField);

        infoPanel.add(receivedKeyLabel);
        infoPanel.add(receivedKeyTextField);
        infoPanel.add(sendMyKeyButton);
        infoPanel.add(resetButton);
        infoPanel.add(commonKeyTextField);
        infoPanel.add(generateCommonKeyButton);
        infoPanel.add(messageTextAreaLabel);
        infoPanel.add(receivedMessageLabel);
        infoPanel.add(decryptedMessageLabel);

        parentPanel.add(statisticsButton);
        parentPanel.add(sendMessageButton);
        parentPanel.add(decryptMessageButton);

        parentPanel.add(keyLabel);
        parentPanel.add(keyTextField);

        infoPanel.add(messageTextArea);
        infoPanel.add(receivedMessageTextArea);
        infoPanel.add(decryptedMessageTextArea);

        clientNoTextField = new JTextField();
        parentPanel.add(displayArea);
        parentPanel.add(infoPanel);
        parentFrame.add(parentPanel);
        setupActionListeners();
    }

    private void setupActionListeners() {
        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                secretNumberATextField.setText("");

               // receivedKeyTextField.setEditable(true);
                receivedKeyTextField.setText("");
                //receivedKeyTextField.setEditable(true);

                commonKeyTextField.setEditable(true);
                commonKeyTextField.setText("");
                commonKeyTextField.setEditable(false);

                r = "";
                displayedReceived = "";
                receivedKeysCounter = 0;
            }
        });


        sendMyKeyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    sNumberA = Integer.parseInt(secretNumberATextField.getText());
                    if (sNumberA < 3) {
                        JOptionPane.showMessageDialog(null, "Invalid key supplied ,\n please ensure you enter an integer greater than 2");
                    } else {
                        publicNo = DeffieHelman.generateCryptoKey(sNumberA);
                        int theMessageType = ClientMessage.MESSAGE_TYPE_SEND_MY_KEY_REQUEST;
                        String theSender = "Client";
                        String theReceiver = "Server";
                        String[] theMessage = {sNumberA + "", publicNo + ""};
                        clientMessage = new ClientMessage(theSender, theReceiver, theMessageType, theMessage);
//                           clientUsername = "";
                        clientObj.sendData(clientMessage);
                        receivedKeys[0] = sNumberA;
                        JOptionPane.showMessageDialog(null, "Key sent successfully! ");
                    }
                } catch (Exception ex1) {
                    JOptionPane.showMessageDialog(null, "Invalid key supplied ,\n please ensure you enter an integer and try again");
                }
//                catch (Exception e2) {
//                    JOptionPane.showMessageDialog(null, "Invalid key supplied for \"Generator\"\n please suppy and integer value","WARNING",JOptionPane.WARNING_MESSAGE);
//                }
            }
        });

        generateCommonKeyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//              JOptionPane.showMessageDialog(null, "sNumberA = "+sNumberA+" \n receivedKeyTextField"+receivedKeyTextField.getText());
                if (!secretNumberATextField.getText().equals(null) && !secretNumberATextField.getText().equals("") && !receivedKeyTextField.getText().equals(null) && !receivedKeyTextField.getText().equals("")) {
                    String[] value = r.split(",");
                    int[] numbers = new int[value.length + 1];
                    numbers[0] = Integer.parseInt(secretNumberATextField.getText());
                    int b = 1;
                    for (int y = 0; y < value.length; y++) {
                        b = y + 1;
                        numbers[b] = Integer.parseInt(value[y]);
                    }

                    theAv = (int) Utilities.getAverage(numbers);
                    int ssecretNumber = theAv;

                    int defaultCrypto = deffiehelman.DeffieHelman.generateCryptoKey(ssecretNumber);
                    int key = deffiehelman.DeffieHelman.generateCommonKey(ssecretNumber, defaultCrypto);

//                    int key = deffiehelman.DeffieHelman.generateCommonKey(sNumberA, theCryptoKey);
//                  JOptionPane.showMessageDialog(null, "key = "+key);
                    commonKeyTextField.setEditable(true);
                    commonKeyTextField.setText(key + "");
                    commonKeyTextField.setEditable(false);

                    receivedKeysCounter = 0;
                    r = "";
                    displayedReceived = "";
                    
                } else {
                    JOptionPane.showMessageDialog(parentPanel, "Missing key(s)-supplied for secret no or received key");
                }
            }
        });

        this.sendMessageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!messageTextArea.getText().equals(null) && !messageTextArea.getText().equals("")) {

                    key = Integer.parseInt(commonKeyTextField.getText());
                    if (key != -1) {
                        String encryptedMessage = CaesarCipher.encryptMessage(messageTextArea.getText(), key);
                        messageTextArea.setText(encryptedMessage);
                        int theMessageType = ClientMessage.MESSAGE_TYPE_SEND_MESSAGE_REQUEST;  //ClientMessage.MESSAGE_TYPE_LOGIN_REQUEST_BY_STAFF; 
                        String theSender = "Client";
                        String theReceiver = "Server";
                        String[] theMessage = {messageTextArea.getText()};
                        System.out.println("plain text = " + encryptedMessage);
                        System.out.println("encryption key = " + key);
                        clientMessage = new ClientMessage(theSender, theReceiver, theMessageType, theMessage);
                        clientUsername = "";
                        clientObj.sendData(clientMessage);
                    } else {
                        JOptionPane.showMessageDialog(null, "Message not sent,Please generate key before sending message ");//,"Warning",JOptionPane.WARNING_MESSAGE); 
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Empty Message, Message not sent");//,"Error",JOptionPane.ERROR);
                }

            }
        });

        this.decryptMessageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int dKey = Integer.parseInt(keyTextField.getText());
//                JOptionPane.showMessageDialog(null, "decrypting :"+receivedMessageTextArea.getText()+"\n"+" with key :"+keyTextField.getText());             
                    String dMessage = CaesarCipher.decryptMessage(receivedMessageTextArea.getText(), dKey);
                    decryptedMessageTextArea.setText(dMessage);
                } catch (Exception e1) {
                    JOptionPane.showMessageDialog(null, "Please enter an integer value for key and try again", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        statisticsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Statistics statistics = new Statistics(clientObj);
                statistics.display();
            }
        });
    }

    public void runClient() {

        try {
            connectToSever();
            getStreams();
            processConnection();
        } catch (EOFException eOFException) {
            displayMessage("\nClient terminated connection");
        } catch (IOException iOException) {
            // iOException.printStackTrace();
            System.out.println(iOException.getMessage());
        } finally {
            closeConnection();
        }
    }

    private void connectToSever() throws IOException {
        displayMessage("Attempting connection to : " + serverIpAddress + "\n");
        try {
            client = new Socket(InetAddress.getByName(serverIpAddress), port);
            connectionStatus = true;
            displayMessage("Connection to: Server " + client.getInetAddress().getHostName() + " was successful");
        } catch (Exception e) {
            connectionStatus = false;
            JOptionPane.showMessageDialog(null, "Connection to Server : " + this.getServerIpAddress() + " Failed");
            parentFrame.dispose();
        }

    }

    private void getStreams() throws IOException {
        try {
            output = new ObjectOutputStream(client.getOutputStream());
            output.flush();
            clientObj = this;
            input = new ObjectInputStream(client.getInputStream());
            displayMessage("\n I/O streams Established Successfully\n");
        } catch (Exception e) {
            displayMessage("\nError in Establishing I/O streams\n");
        }
    }

    private void processConnection() throws IOException {
        setTextFieldEditable(true);
        int[] numbers;
        do {
            try {
                serverMessage = (ServerMessage) input.readObject();
//analyse message r from server and give appropriate response
                if (serverMessage.getMessageType() == ServerMessage.SENDING_KEY_REQUEST) {
                    if (receivedKeysCounter == 0) {
                        r = serverMessage.getMessage()[0];
                        displayedReceived = Integer.parseInt(serverMessage.getMessage()[1] )+ DeffieHelman.generateCryptoKey(Integer.parseInt(serverMessage.getMessage()[1]) )+"";
                    } else {
                        r = r + "," + serverMessage.getMessage()[0];
                        displayedReceived = displayedReceived + "," + DeffieHelman.generateCryptoKey(Integer.parseInt(serverMessage.getMessage()[1])) + "";
//                    displayedReceived = DeffieHelman.generateCryptoKey(Integer.parseInt(serverMessage.getMessage()[0])) + "";
                    }
                    receivedKeysCounter++;
//                    JOptionPane.showMessageDialog(null, "r "+r);
                    this.receivedKeyTextField.setText(displayedReceived);
                    String[] theMessage = {};
                    int theMessageType = ClientMessage.KEY_RECEIVED;  //ClientMessage.MESSAGE_TYPE_LOGIN_REQUEST_BY_STAFF; 
                    String theSender = "Client";
                    String theReceiver = "Server";
                    clientMessage = new ClientMessage(theSender, theReceiver, theMessageType, theMessage);
                    clientUsername = "";
                    clientObj.sendData(clientMessage);                   
                } else if (serverMessage.getMessageType() == ServerMessage.KEY_SENT_SUCCESSFULLY) {
//                    JOptionPane.showMessageDialog(parentFrame, "Key sent successfully");
                } else if (serverMessage.getMessageType() == ServerMessage.SEND_MESSAGE_TO_OTHER_CLIENTS_REQUEST) {
                    receivedMessageTextArea.setEditable(true);
                    this.receivedMessageTextArea.setText(serverMessage.getMessage()[0]);
                    receivedMessageTextArea.setEditable(false);
                }
            } catch (ClassNotFoundException classNotFoundException) {
                displayMessage("\nUnknown object type received");
            }
        } while (serverMessage.getMessageType() != ServerMessage.MESSAGE_TYPE_CONNECTION_TERMINATED);

        JOptionPane.showMessageDialog(null, "Connection to Server Lost/Terminated");
    }

    public void closeConnection() {
//        displayMessage("\nClossing connection");
//        setTextFieldEditable(false);
        try {
            output.close();
            input.close();
            client.close();
        } catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

//    private void sendData(String message) {
//        try {
//            if (!clientNoTextField.getText().equals("") && !clientNoTextField.getText().equals(null)) {//private message
//                String sms = message; //Cryptography.encryptMessage(message, key);//encrypts message
//                output.writeObject(">>>" + sms + "~" + clientNoTextField.getText() + "`");
//                output.flush();
//            } else {//public message
//                output.writeObject(">>>" + message);
//                output.flush();
//            }
//            // displayMessage("\nCLIENT>>> " + message);
//        } catch (IOException iOException) {
//            displayArea.append("\nError writing object");
//        }
//    }

    public void sendData(ClientMessage message) { 
        try {
            output.writeObject(message);
            output.flush();
        } catch (IOException iOException) {
            JOptionPane.showMessageDialog(null, "IOException sending message to server at client.sendData()");
        }//end catch
    }

    private void displayMessage(final String messageToDisplay) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                displayArea.append(messageToDisplay);
                displayArea.setEditable(false);
            }
        });
    }

    private void setTextFieldEditable(final boolean editable) {
//        SwingUtilities.invokeLater(new Runnable() {
//            @Override
//            public void run() {
//                enterField.setEditable(editable);
//            }
//        });
    }

    public boolean isUserValid() {
        boolean status = false;
        try {
            serverIncomingMessage = (ServerMessage) input.readObject();
            //JOptionPane.showMessageDialog(null, "Client recieved \n" + message);
            if (serverIncomingMessage.getMessage()[0].equals("1")) {
                status = true;
            } else {
                status = false;
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "I/O exception\n");
        } catch (ClassNotFoundException classNotFoundException) {
            JOptionPane.showMessageDialog(null, "\nUnknown object type receivedby client");
        }

        return status;
    }//end isUserValid()

//    public void readChatMessage() {
//        //do{
//        try {
//            serverIncomingMessage = (ServerMessage) input.readObject();
//            //JOptionPane.showMessageDialog(null, "Client recieved \n" + serverIncomingMessage);
//        } catch (IOException ex) {
//            //JOptionPane.showMessageDialog(null, "I/O exception\n");
//        } catch (ClassNotFoundException classNotFoundException) {
//            // JOptionPane.showMessageDialog(null, "\nUnknown object type receivedby client");
//        }
//        // }while(!serverIncomingMessage.getMessage()[0].equals("stop"));
//    }
    public String getClientUsername() {
        return clientUsername;
    }
//           public void sendData(ClientMessage message) {
//        try {
//            output.writeObject(message);
//            output.flush();
//        } catch (IOException iOException) {
//            JOptionPane.showMessageDialog(null, "IOException sending message to server at client.sendData()");
//        }//end catch
//    }
//    public static String hostIpAddress = "127.0.0.1";
//
//    public static void main(String[] args) {
//        Client application;
//        if (args.length == 0) {
//            //String host = "169.254.93.237";
//            // String host = "192.168.43.71";^
//            //"169.254.234.187"; String host = "169.254.181.210"; //"169.254.234.187";                         
//            application = new Client(hostIpAddress);
//        } else {
//            application = new Client(args[0]);
//        }
//        application.runClient();
//    }
}
